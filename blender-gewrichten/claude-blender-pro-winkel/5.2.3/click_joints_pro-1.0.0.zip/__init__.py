"""Click Joints: snijdt een figuur in twee printbare delen met een kogel- of pengewricht."""
import bpy

from . import eigenschappen, exporteer, gesloten, gewricht, paneel, schaal, waaier

MODULES = (eigenschappen, gesloten, gewricht, exporteer, schaal, waaier, paneel)


def register():
    for m in MODULES:
        for k in m.KLASSEN:
            bpy.utils.register_class(k)
    eigenschappen.koppel()
    waaier.koppel()


def unregister():
    waaier.ontkoppel()
    eigenschappen.ontkoppel()
    for m in reversed(MODULES):
        for k in reversed(m.KLASSEN):
            bpy.utils.unregister_class(k)


# Alleen in de betaalde build: maak_zip.sh zet dit achter __init__.py (ontwerp betaald v1.1).
from . import betaald as _betaald  # noqa: E402

_register_kern, _unregister_kern = register, unregister  # noqa: F821  (fragment achter __init__.py)


def register():  # noqa: F811
    _betaald.weiger_dubbel(__package__)
    _register_kern()
    _betaald.register(__package__)


def unregister():  # noqa: F811
    _betaald.unregister()
    _unregister_kern()
